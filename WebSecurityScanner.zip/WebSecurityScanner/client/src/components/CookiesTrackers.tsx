import { Card, CardContent } from "@/components/ui/card";
import { CookiesTrackersDetail } from "@/lib/types";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Cookie } from "lucide-react";

interface CookiesTrackersProps {
  details: CookiesTrackersDetail;
}

export default function CookiesTrackers({ details }: CookiesTrackersProps) {
  // Calculate percentage for progress bars
  const cookiePercentage = Math.min(details.cookieCount * 4, 100);
  const trackerPercentage = Math.min(details.trackerCount * 7, 100);
  
  // Get styles based on tracking level
  const getTrackingLevelStyle = (level: string) => {
    switch (level) {
      case 'low':
        return 'bg-green-900/50 text-green-400';
      case 'moderate':
        return 'bg-amber-900/50 text-amber-400';
      case 'high':
        return 'bg-red-900/50 text-red-400';
      default:
        return 'bg-blue-900/50 text-blue-400';
    }
  };
  
  // Get color for progress bars
  const getProgressColor = (percentage: number) => {
    if (percentage < 33) return 'bg-status-success';
    if (percentage < 66) return 'bg-status-warning';
    return 'bg-status-danger';
  };
  
  const trackingLevelStyle = getTrackingLevelStyle(details.thirdPartyTracking);
  const cookieProgressColor = getProgressColor(cookiePercentage);
  const trackerProgressColor = getProgressColor(trackerPercentage);

  return (
    <Card className="bg-secondary border-border h-full">
      <CardContent className="pt-5">
        <div className="flex items-center mb-4">
          <div className="w-10 h-10 rounded-full bg-blue-900/30 flex items-center justify-center mr-3">
            <Cookie className="text-blue-400" />
          </div>
          <h3 className="text-lg font-semibold">Cookies & Trackers</h3>
        </div>
        
        <div className="mb-4">
          <div className="flex justify-between text-foreground text-sm mb-2">
            <span>Cookies</span>
            <span>{details.cookieCount} detected</span>
          </div>
          <Progress value={cookiePercentage} className={cookieProgressColor} />
        </div>
        
        <div className="mb-4">
          <div className="flex justify-between text-foreground text-sm mb-2">
            <span>Trackers</span>
            <span>{details.trackerCount} detected</span>
          </div>
          <Progress value={trackerPercentage} className={trackerProgressColor} />
        </div>
        
        <div className="bg-background rounded-lg p-3 mt-4">
          <div className="flex justify-between items-center mb-2">
            <span className="font-medium">Third-party tracking</span>
            <Badge className={trackingLevelStyle}>
              {details.thirdPartyTracking.charAt(0).toUpperCase() + details.thirdPartyTracking.slice(1)}
            </Badge>
          </div>
          <p className="text-muted-foreground text-sm">{details.description}</p>
        </div>
      </CardContent>
    </Card>
  );
}
