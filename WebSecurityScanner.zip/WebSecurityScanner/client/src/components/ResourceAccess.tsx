import { Card, CardContent } from "@/components/ui/card";
import { ResourceAccessItem } from "@/lib/types";
import { 
  Camera, 
  Mic, 
  MapPin, 
  Bell, 
  CheckCircle, 
  XCircle 
} from "lucide-react";

// Map icon string to Lucide icon component
const getIcon = (icon: string) => {
  switch (icon) {
    case 'camera':
      return <Camera className="h-5 w-5" />;
    case 'microphone':
      return <Mic className="h-5 w-5" />;
    case 'map-marker-alt':
      return <MapPin className="h-5 w-5" />;
    case 'bell':
      return <Bell className="h-5 w-5" />;
    default:
      return <Camera className="h-5 w-5" />;
  }
};

interface ResourceAccessProps {
  resources: ResourceAccessItem[];
}

export default function ResourceAccess({ resources }: ResourceAccessProps) {
  return (
    <Card className="bg-secondary border-border h-full">
      <CardContent className="pt-5">
        <div className="flex items-center mb-4">
          <div className="w-10 h-10 rounded-full bg-yellow-900/30 flex items-center justify-center mr-3">
            <Mic className="text-amber-500" />
          </div>
          <h3 className="text-lg font-semibold">Resource Access</h3>
        </div>
        
        <ul className="space-y-3">
          {resources.map((resource, index) => (
            <li key={index} className="flex items-center text-foreground">
              {resource.status === 'not_requested' ? (
                <XCircle className="text-status-success mr-2 h-5 w-5" />
              ) : (
                <CheckCircle className="text-status-warning mr-2 h-5 w-5" />
              )}
              
              <span>
                {resource.name}: {' '}
                <span className={resource.status === 'not_requested' ? 'text-status-success' : 'text-status-warning'}>
                  {resource.status === 'not_requested' ? 'Not requested' : 'Requested'}
                </span>
              </span>
            </li>
          ))}
        </ul>
      </CardContent>
    </Card>
  );
}
