import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { SecurityMetric } from "@/lib/types";
import { 
  ShieldCheck, 
  Bug, 
  UserX, 
  Lock, 
  AlertTriangle, 
  CheckCircle,
  XCircle
} from "lucide-react";

// Map status to icon component
const getIcon = (icon: string) => {
  switch (icon) {
    case 'shield-alt':
      return <ShieldCheck className="h-5 w-5" />;
    case 'bug':
      return <Bug className="h-5 w-5" />;
    case 'user-secret':
      return <UserX className="h-5 w-5" />;
    case 'lock':
      return <Lock className="h-5 w-5" />;
    case 'exclamation-triangle':
      return <AlertTriangle className="h-5 w-5" />;
    default:
      return <CheckCircle className="h-5 w-5" />;
  }
};

// Map status to style classes
const getStatusStyles = (status: string) => {
  switch (status) {
    case 'success':
      return 'text-status-success';
    case 'warning':
      return 'text-status-warning';
    case 'danger':
      return 'text-status-danger';
    default:
      return 'text-status-success';
  }
};

interface SecurityFeatureItemProps {
  name: string;
  present: boolean;
}

export function SecurityFeatureItem({ name, present }: SecurityFeatureItemProps) {
  return (
    <li className="flex items-center text-foreground">
      {present ? (
        <CheckCircle className="text-status-success mr-2 h-5 w-5" />
      ) : (
        <XCircle className="text-status-danger mr-2 h-5 w-5" />
      )}
      <span>{name}</span>
    </li>
  );
}

interface SecurityMetricsProps {
  metrics: SecurityMetric[];
}

export function SecurityMetrics({ metrics }: SecurityMetricsProps) {
  return (
    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
      {metrics.map((metric, index) => (
        <div key={index} className="bg-background rounded-lg p-3 text-center">
          <div className={`mb-1 ${getStatusStyles(metric.status)}`}>
            {getIcon(metric.icon)}
          </div>
          <div className="text-sm">{metric.name}</div>
          <div className="font-semibold">{metric.value}</div>
        </div>
      ))}
    </div>
  );
}

interface SecurityDetailsProps {
  url: string;
  score: number;
  status: 'secure' | 'warning' | 'vulnerable';
  scanDate: string;
  securityMetrics: SecurityMetric[];
}

export default function SecurityDetails({ 
  url, 
  score, 
  status,
  scanDate,
  securityMetrics 
}: SecurityDetailsProps) {
  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'secure':
        return <Badge className="bg-green-600">Secure</Badge>;
      case 'warning':
        return <Badge className="bg-amber-500">Warning</Badge>;
      case 'vulnerable':
        return <Badge className="bg-red-600">Vulnerable</Badge>;
      default:
        return <Badge className="bg-slate-500">Unknown</Badge>;
    }
  };

  return (
    <Card className="bg-secondary border-border shadow-md">
      <CardContent className="pt-6">
        <div className="flex justify-between items-center mb-4">
          <h3 className="text-xl font-semibold">Security Analysis Results</h3>
          {getStatusBadge(status)}
        </div>
        
        <div className="mb-4">
          <p className="text-foreground mb-2">
            <span className="font-medium">Website:</span> {' '}
            <span className="text-muted-foreground">{url}</span>
          </p>
          <p className="text-foreground">
            <span className="font-medium">Scan Date:</span> {' '}
            <span className="text-muted-foreground">{scanDate}</span>
          </p>
        </div>
        
        <SecurityMetrics metrics={securityMetrics} />
      </CardContent>
    </Card>
  );
}
