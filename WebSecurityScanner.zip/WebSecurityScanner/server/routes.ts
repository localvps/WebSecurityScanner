import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { securityScanner } from "./services/scanner";
import { urlSchema, insertScanSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // API routes for the security scanner
  const apiRouter = app.route('/api');

  // Endpoint to scan a URL for security vulnerabilities
  app.post('/api/scan', async (req: Request, res: Response) => {
    try {
      // Validate URL
      const validatedData = urlSchema.parse(req.body);
      const url = validatedData.url;

      // Perform security scan
      const scanResult = await securityScanner.scanUrl(url);

      // Store scan result in storage
      const scanData = {
        url: scanResult.url,
        score: scanResult.score,
        status: scanResult.status,
        securityDetails: JSON.stringify(scanResult.securityMetrics),
        vulnerabilities: JSON.stringify(scanResult.vulnerabilities),
        resourceAccess: JSON.stringify(scanResult.resourceAccess),
        cookiesTrackers: JSON.stringify(scanResult.cookiesTrackers),
        recommendations: JSON.stringify(scanResult.recommendations)
      };

      // Store the scan result
      await storage.createScan(scanData);

      // Return the scan result
      res.json(scanResult);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: error.errors[0].message });
      } else {
        console.error('Scan error:', error);
        res.status(500).json({ message: 'Failed to scan the URL' });
      }
    }
  });

  // Endpoint to get recent scans
  app.get('/api/scans/recent', async (req: Request, res: Response) => {
    try {
      const limit = parseInt(req.query.limit as string) || 10;
      const recentScans = await storage.getRecentScans(limit);
      
      // Map database scans to ScanResult objects
      const formattedScans = recentScans.map(scan => ({
        id: scan.id,
        url: scan.url,
        score: scan.score,
        status: scan.status,
        scanDate: scan.scanDate.toLocaleString('en-US', {
          year: 'numeric',
          month: 'long',
          day: 'numeric',
          hour: '2-digit',
          minute: '2-digit'
        })
      }));
      
      res.json(formattedScans);
    } catch (error) {
      console.error('Error fetching recent scans:', error);
      res.status(500).json({ message: 'Failed to fetch recent scans' });
    }
  });

  // Endpoint to get all scans
  app.get('/api/scans', async (req: Request, res: Response) => {
    try {
      const allScans = await storage.getAllScans();
      
      // Map database scans to ScanResult objects
      const formattedScans = allScans.map(scan => ({
        id: scan.id,
        url: scan.url,
        score: scan.score,
        status: scan.status,
        scanDate: scan.scanDate.toLocaleString('en-US', {
          year: 'numeric',
          month: 'long',
          day: 'numeric',
          hour: '2-digit',
          minute: '2-digit'
        })
      }));
      
      res.json(formattedScans);
    } catch (error) {
      console.error('Error fetching all scans:', error);
      res.status(500).json({ message: 'Failed to fetch scans' });
    }
  });

  // Endpoint to get a specific scan by ID
  app.get('/api/scans/:id', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: 'Invalid scan ID' });
      }
      
      const scan = await storage.getScan(id);
      
      if (!scan) {
        return res.status(404).json({ message: 'Scan not found' });
      }
      
      // Convert stored JSON strings back to objects
      const result = {
        id: scan.id,
        url: scan.url,
        score: scan.score,
        status: scan.status,
        scanDate: scan.scanDate.toLocaleString('en-US', {
          year: 'numeric',
          month: 'long',
          day: 'numeric',
          hour: '2-digit',
          minute: '2-digit'
        }),
        securityMetrics: JSON.parse(scan.securityDetails),
        vulnerabilities: JSON.parse(scan.vulnerabilities),
        resourceAccess: JSON.parse(scan.resourceAccess),
        cookiesTrackers: JSON.parse(scan.cookiesTrackers),
        recommendations: JSON.parse(scan.recommendations)
      };
      
      res.json(result);
    } catch (error) {
      console.error('Error fetching scan:', error);
      res.status(500).json({ message: 'Failed to fetch scan details' });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
