import { useQuery } from "@tanstack/react-query";
import HistoryTable from "@/components/HistoryTable";
import { ScanHistoryItem } from "@/lib/types";
import { History as HistoryIcon } from "lucide-react";

export default function History() {
  const { 
    data: scans, 
    isLoading 
  } = useQuery<ScanHistoryItem[]>({
    queryKey: ['/api/scans'], 
    queryOptions: {
      refetchOnWindowFocus: false
    }
  });

  return (
    <div className="py-6">
      <div className="flex items-center mb-6">
        <HistoryIcon className="h-8 w-8 text-primary mr-3" />
        <h1 className="text-3xl font-bold">Scan History</h1>
      </div>
      
      <p className="text-muted-foreground mb-8">
        View all your previous website security scans. Click on "View Report" to see the detailed security analysis.
      </p>
      
      <HistoryTable 
        scans={scans || []} 
        isLoading={isLoading} 
      />
    </div>
  );
}
