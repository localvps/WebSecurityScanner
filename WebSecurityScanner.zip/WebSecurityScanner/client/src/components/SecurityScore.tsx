import { useEffect, useState } from "react";

interface SecurityScoreProps {
  score: number;
}

export default function SecurityScore({ score }: SecurityScoreProps) {
  const [animatedScore, setAnimatedScore] = useState(0);
  
  // Calculate stroke colors based on score
  const getScoreColor = (score: number) => {
    if (score >= 70) return 'var(--success)';
    if (score >= 40) return 'var(--warning)';
    return 'var(--danger)';
  };
  
  const scoreColor = getScoreColor(score);
  
  // Calculate the stroke dash offset for the SVG circle
  // Circle circumference is 2 * PI * radius
  const radius = 54;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (animatedScore / 100) * circumference;
  
  // Animate the score when it changes
  useEffect(() => {
    const duration = 1500; // Animation duration in ms
    const interval = 20; // Update interval in ms
    const steps = duration / interval;
    const increment = score / steps;
    let currentScore = 0;
    
    const timer = setInterval(() => {
      currentScore += increment;
      
      if (currentScore >= score) {
        setAnimatedScore(score);
        clearInterval(timer);
      } else {
        setAnimatedScore(Math.floor(currentScore));
      }
    }, interval);
    
    return () => clearInterval(timer);
  }, [score]);

  return (
    <div className="text-center">
      <div className="relative inline-flex justify-center items-center">
        <svg className="w-40 h-40" viewBox="0 0 120 120">
          {/* Background circle */}
          <circle 
            cx="60" 
            cy="60" 
            r={radius} 
            fill="none" 
            stroke="currentColor" 
            strokeOpacity="0.1" 
            strokeWidth="12" 
          />
          
          {/* Score circle with animation */}
          <circle 
            cx="60" 
            cy="60" 
            r={radius} 
            fill="none" 
            stroke={scoreColor} 
            strokeWidth="12" 
            strokeDasharray={circumference}
            strokeDashoffset={strokeDashoffset}
            transform="rotate(-90 60 60)"
            style={{ transition: 'stroke-dashoffset 0.5s ease-in-out' }}
          />
        </svg>
        <div className="absolute inset-0 flex flex-col justify-center items-center">
          <span className="text-4xl font-bold">{animatedScore}</span>
          <span className="text-sm text-muted-foreground">Security Score</span>
        </div>
      </div>
    </div>
  );
}
