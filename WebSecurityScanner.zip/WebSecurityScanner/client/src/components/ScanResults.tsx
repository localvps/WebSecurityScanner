import { ScanResult } from "@/lib/types";
import SecurityScore from "./SecurityScore";
import SecurityDetails from "./SecurityDetails";
import { SecurityFeatureItem } from "./SecurityDetails";
import ResourceAccess from "./ResourceAccess";
import Vulnerabilities from "./Vulnerabilities";
import CookiesTrackers from "./CookiesTrackers";
import Recommendations from "./Recommendations";
import { Card, CardContent } from "@/components/ui/card";
import { ShieldCheck } from "lucide-react";

interface ScanResultsProps {
  result: ScanResult;
}

export default function ScanResults({ result }: ScanResultsProps) {
  return (
    <section className="mt-10 space-y-8">
      <div className="bg-secondary rounded-xl p-6 shadow-lg border border-border mb-8">
        <div className="flex flex-col md:flex-row items-start md:items-center">
          <div className="md:w-1/3 flex justify-center mb-6 md:mb-0">
            <SecurityScore score={result.score} />
          </div>
          <div className="md:w-2/3 md:pl-8">
            <SecurityDetails 
              url={result.url} 
              score={result.score} 
              status={result.status}
              scanDate={result.scanDate}
              securityMetrics={result.securityMetrics}
            />
          </div>
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-6 mb-8">
        <Card className="bg-secondary border-border h-full">
          <CardContent className="pt-5">
            <div className="flex items-center mb-4">
              <div className="w-10 h-10 rounded-full bg-green-900/30 flex items-center justify-center mr-3">
                <ShieldCheck className="text-status-success" />
              </div>
              <h3 className="text-lg font-semibold">Security Features</h3>
            </div>
            <ul className="space-y-3">
              {result.securityFeatures.map((feature, index) => (
                <SecurityFeatureItem 
                  key={index} 
                  name={feature.name} 
                  present={feature.present} 
                />
              ))}
            </ul>
          </CardContent>
        </Card>
        
        <ResourceAccess resources={result.resourceAccess} />
      </div>

      <div className="grid md:grid-cols-2 gap-6 mb-8">
        <Vulnerabilities vulnerabilities={result.vulnerabilities} />
        <CookiesTrackers details={result.cookiesTrackers} />
      </div>

      <Recommendations recommendations={result.recommendations} />
    </section>
  );
}
