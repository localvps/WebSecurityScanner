import { Card, CardContent } from "@/components/ui/card";
import { ShieldCheck, Lock, AlertTriangle, Server } from "lucide-react";

export default function About() {
  return (
    <div className="py-6">
      <h1 className="text-3xl font-bold mb-6">About WebSecurityScan</h1>
      
      <div className="mb-8">
        <p className="text-muted-foreground mb-4">
          WebSecurityScan is a powerful tool designed to help you evaluate the security posture of websites before sharing sensitive information.
          Our scanner checks for common vulnerabilities, privacy concerns, and security best practices to provide you with an easy-to-understand security score.
        </p>
        <p className="text-muted-foreground">
          Whether you're a security professional, website owner, or just a privacy-conscious internet user, our tool provides valuable insights to help you
          stay safe online.
        </p>
      </div>
      
      <h2 className="text-2xl font-bold mb-4">How Our Scanner Works</h2>
      
      <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <Card className="bg-secondary border-border">
          <CardContent className="pt-6">
            <div className="flex flex-col items-center text-center">
              <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                <Server className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-lg font-semibold mb-2">URL Analysis</h3>
              <p className="text-muted-foreground text-sm">
                We fetch and analyze the target website, checking its configuration, headers, and content.
              </p>
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-secondary border-border">
          <CardContent className="pt-6">
            <div className="flex flex-col items-center text-center">
              <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                <ShieldCheck className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-lg font-semibold mb-2">Security Checks</h3>
              <p className="text-muted-foreground text-sm">
                We evaluate SSL implementation, security headers, and protection against common vulnerabilities.
              </p>
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-secondary border-border">
          <CardContent className="pt-6">
            <div className="flex flex-col items-center text-center">
              <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                <Lock className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-lg font-semibold mb-2">Privacy Assessment</h3>
              <p className="text-muted-foreground text-sm">
                We detect what permissions the site requests and what tracking technologies are in use.
              </p>
            </div>
          </CardContent>
        </Card>
        
        <Card className="bg-secondary border-border">
          <CardContent className="pt-6">
            <div className="flex flex-col items-center text-center">
              <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center mb-4">
                <AlertTriangle className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-lg font-semibold mb-2">Recommendations</h3>
              <p className="text-muted-foreground text-sm">
                We provide actionable advice to enhance security and fix detected issues.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
      
      <h2 className="text-2xl font-bold mb-4">Why Security Matters</h2>
      
      <div className="bg-secondary border border-border rounded-lg p-6 mb-8">
        <div className="prose prose-invert max-w-none">
          <p>
            In today's digital world, website security is more important than ever. Insecure websites can:
          </p>
          <ul>
            <li>Expose your personal information to attackers</li>
            <li>Install malware on your devices</li>
            <li>Track your online behavior without consent</li>
            <li>Become compromised and serve malicious content</li>
          </ul>
          <p>
            By using WebSecurityScan before interacting with unfamiliar websites, you can make informed decisions
            about which sites to trust with your information and which to avoid.
          </p>
        </div>
      </div>
      
      <h2 className="text-2xl font-bold mb-4">Our Technology</h2>
      
      <p className="text-muted-foreground mb-6">
        WebSecurityScan uses modern security assessment techniques to provide accurate and helpful security analysis:
      </p>
      
      <div className="grid md:grid-cols-2 gap-6 mb-8">
        <Card className="bg-secondary border-border">
          <CardContent className="pt-6">
            <h3 className="text-lg font-semibold mb-2">Security Headers Analysis</h3>
            <p className="text-muted-foreground">
              We check for implementation of critical security headers like Content-Security-Policy,
              X-XSS-Protection, and HTTP Strict Transport Security (HSTS) that help protect against common attacks.
            </p>
          </CardContent>
        </Card>
        
        <Card className="bg-secondary border-border">
          <CardContent className="pt-6">
            <h3 className="text-lg font-semibold mb-2">SSL/TLS Verification</h3>
            <p className="text-muted-foreground">
              We verify that websites are using HTTPS with proper SSL/TLS implementation to ensure
              encrypted communication between your browser and the website.
            </p>
          </CardContent>
        </Card>
        
        <Card className="bg-secondary border-border">
          <CardContent className="pt-6">
            <h3 className="text-lg font-semibold mb-2">Resource Permission Detection</h3>
            <p className="text-muted-foreground">
              We detect when websites request sensitive permissions like camera, microphone, or geolocation access
              that could potentially compromise your privacy.
            </p>
          </CardContent>
        </Card>
        
        <Card className="bg-secondary border-border">
          <CardContent className="pt-6">
            <h3 className="text-lg font-semibold mb-2">Cookies & Trackers Analysis</h3>
            <p className="text-muted-foreground">
              We identify cookies and third-party tracking scripts to help you understand how a website
              might be collecting and sharing your data.
            </p>
          </CardContent>
        </Card>
      </div>
      
      <div className="bg-primary/10 border border-primary/20 rounded-lg p-6 text-center">
        <h2 className="text-xl font-bold mb-3">Start Scanning Today</h2>
        <p className="text-muted-foreground mb-4">
          Take control of your online security and privacy by scanning websites before you trust them with your information.
        </p>
      </div>
    </div>
  );
}
