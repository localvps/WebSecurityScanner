import { ScanResult, SecurityMetric, SecurityFeature, ResourceAccessItem, Vulnerability, Recommendation } from "@shared/schema";
import axios from "axios";
import * as cheerio from "cheerio";
import * as urlParser from "url-parse";

// Security scanner service
export class SecurityScanner {
  
  // Main scan method that takes a URL and returns a ScanResult
  async scanUrl(url: string): Promise<ScanResult> {
    try {
      // Ensure URL has protocol
      if (!url.startsWith('http://') && !url.startsWith('https://')) {
        url = 'https://' + url;
      }

      // Parse the URL
      const parsedUrl = urlParser(url, true);
      const domain = parsedUrl.hostname;
      
      // Attempt to fetch the website
      const response = await axios.get(url, {
        timeout: 5000,
        headers: {
          'User-Agent': 'WebSecurityScan/1.0'
        },
        validateStatus: () => true // Accept any HTTP status code
      });

      // Calculate security score and generate detailed report
      return this.generateSecurityReport(url, response);
    } catch (error) {
      // Handle fetch errors
      const errorScore = 30;
      return this.generateErrorReport(url, error, errorScore);
    }
  }

  // Generate a detailed security report based on the response
  private generateSecurityReport(url: string, response: any): ScanResult {
    // Extract the hostname from the URL
    const parsedUrl = urlParser(url, true);
    const domain = parsedUrl.hostname;
    
    // Check if HTTPS is used
    const isHttps = url.startsWith('https://');
    
    // Extract headers for security analysis
    const headers = response.headers;
    
    // Parse HTML content
    const $ = cheerio.load(response.data);
    
    // Security score calculation (base score from different factors)
    let score = 50; // Start with a neutral score
    
    // Add points for HTTPS
    if (isHttps) {
      score += 20;
    } else {
      score -= 20;
    }
    
    // Check security headers
    if (headers['content-security-policy']) score += 5;
    if (headers['strict-transport-security']) score += 5;
    if (headers['x-content-type-options']) score += 5;
    if (headers['x-frame-options']) score += 5;
    if (headers['x-xss-protection']) score += 5;
    
    // Check for external scripts/resources
    const externalScripts = $('script[src]').filter((i, el) => {
      const src = $(el).attr('src') || '';
      return src.startsWith('http') && !src.includes(domain);
    }).length;
    
    // More external scripts can reduce score
    score -= Math.min(externalScripts, 5);
    
    // Check for resource access permissions
    const hasGeolocation = $('script').text().includes('navigator.geolocation');
    const hasCamera = $('script').text().includes('getUserMedia') || 
                    $('script').text().includes('mediaDevices.getUserMedia');
    const hasMicrophone = hasCamera; // Usually requested together
    const hasNotifications = $('script').text().includes('Notification.requestPermission');
    
    // Adjust score based on resource access
    if (hasGeolocation || hasCamera || hasMicrophone) {
      score -= 5;
    }
    
    // Clamp score between 0 and 100
    score = Math.max(0, Math.min(100, score));
    
    // Determine status based on score
    let status: 'secure' | 'warning' | 'vulnerable' = 'vulnerable';
    if (score >= 70) {
      status = 'secure';
    } else if (score >= 40) {
      status = 'warning';
    }
    
    // Generate the current date in a readable format
    const scanDate = new Date().toLocaleString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
    
    // Generate security metrics
    const securityMetrics: SecurityMetric[] = [
      {
        name: 'SSL Security',
        value: isHttps ? 'Excellent' : 'Missing',
        status: isHttps ? 'success' : 'danger',
        icon: 'shield-alt'
      },
      {
        name: 'Malware',
        value: 'Not Detected',
        status: 'success',
        icon: 'bug'
      },
      {
        name: 'Privacy',
        value: (hasGeolocation || hasCamera) ? 'Concerning' : 'Moderate',
        status: (hasGeolocation || hasCamera) ? 'warning' : 'success',
        icon: 'user-secret'
      },
      {
        name: 'Data Protection',
        value: headers['content-security-policy'] ? 'Strong' : 'Weak',
        status: headers['content-security-policy'] ? 'success' : 'warning',
        icon: 'lock'
      }
    ];
    
    // Generate security features
    const securityFeatures: SecurityFeature[] = [
      {
        name: 'HTTPS encryption',
        present: isHttps
      },
      {
        name: 'Valid SSL certificate',
        present: isHttps
      },
      {
        name: 'Content Security Policy',
        present: !!headers['content-security-policy']
      },
      {
        name: 'HSTS preloading',
        present: !!headers['strict-transport-security']
      },
      {
        name: 'XSS Protection',
        present: !!headers['x-xss-protection']
      }
    ];
    
    // Generate resource access details
    const resourceAccess: ResourceAccessItem[] = [
      {
        name: 'Camera access',
        status: hasCamera ? 'requested' : 'not_requested',
        icon: 'camera'
      },
      {
        name: 'Microphone access',
        status: hasMicrophone ? 'requested' : 'not_requested',
        icon: 'microphone'
      },
      {
        name: 'Geolocation',
        status: hasGeolocation ? 'requested' : 'not_requested',
        icon: 'map-marker-alt'
      },
      {
        name: 'Notification permission',
        status: hasNotifications ? 'requested' : 'not_requested',
        icon: 'bell'
      }
    ];
    
    // Count cookies and trackers
    const cookieHeader = headers['set-cookie'] || [];
    const cookieCount = Array.isArray(cookieHeader) ? cookieHeader.length : 1;
    
    // Count potential trackers (analytics, ad scripts, etc.)
    const trackerScripts = $('script[src]').filter((i, el) => {
      const src = $(el).attr('src') || '';
      return src.includes('analytics') || 
             src.includes('tracker') || 
             src.includes('pixel') ||
             src.includes('ads') ||
             src.includes('tag');
    }).length;
    
    // Determine third-party tracking level
    let thirdPartyTracking: 'low' | 'moderate' | 'high' = 'low';
    if (trackerScripts > 5 || cookieCount > 10) {
      thirdPartyTracking = 'high';
    } else if (trackerScripts > 2 || cookieCount > 5) {
      thirdPartyTracking = 'moderate';
    }
    
    // Generate cookies and trackers info
    const cookiesTrackers = {
      cookieCount,
      trackerCount: trackerScripts,
      thirdPartyTracking,
      description: `This website uses ${thirdPartyTracking} tracking through analytics and advertising services.`
    };
    
    // Generate vulnerabilities list
    const vulnerabilities: Vulnerability[] = [];
    
    if (!isHttps) {
      vulnerabilities.push({
        name: 'Insecure HTTP Protocol',
        description: 'The website is not using HTTPS, which means data is not encrypted during transmission.',
        status: 'danger'
      });
    }
    
    if (!headers['x-xss-protection']) {
      vulnerabilities.push({
        name: 'Cross-Site Scripting (XSS) Protection',
        description: 'The X-XSS-Protection header is not set, which could make the site vulnerable to cross-site scripting attacks.',
        status: 'warning'
      });
    }
    
    if (!headers['content-security-policy']) {
      vulnerabilities.push({
        name: 'Content Security Policy',
        description: 'No Content Security Policy is implemented, which helps prevent various types of attacks including XSS and data injection.',
        status: 'warning'
      });
    }
    
    // Generate recommendations
    const recommendations: Recommendation[] = [];
    
    if (!isHttps) {
      recommendations.push({
        title: 'Enable HTTPS',
        description: 'Switch to HTTPS to encrypt data during transmission between the user and your website.'
      });
    }
    
    if (!headers['strict-transport-security']) {
      recommendations.push({
        title: 'Enable HTTP Strict Transport Security (HSTS)',
        description: 'HSTS ensures that your website is always accessed via HTTPS, protecting against downgrade attacks.'
      });
    }
    
    if (!headers['x-content-type-options']) {
      recommendations.push({
        title: 'Set X-Content-Type-Options header',
        description: 'Prevent MIME-type sniffing attacks by setting the X-Content-Type-Options header to \'nosniff\'.'
      });
    }
    
    if (!headers['x-frame-options']) {
      recommendations.push({
        title: 'Set X-Frame-Options header',
        description: 'Prevent clickjacking attacks by setting the X-Frame-Options header to deny or same-origin.'
      });
    }
    
    // Return the complete scan result
    return {
      url,
      score,
      status,
      scanDate,
      securityMetrics,
      securityFeatures,
      resourceAccess,
      vulnerabilities,
      cookiesTrackers,
      recommendations
    };
  }

  // Generate an error report when the scan fails
  private generateErrorReport(url: string, error: any, score: number): ScanResult {
    const scanDate = new Date().toLocaleString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
    
    // Basic error report
    return {
      url,
      score,
      status: 'warning',
      scanDate,
      securityMetrics: [
        {
          name: 'Connection',
          value: 'Failed',
          status: 'danger',
          icon: 'exclamation-triangle'
        },
        {
          name: 'SSL Security',
          value: 'Unknown',
          status: 'warning',
          icon: 'shield-alt'
        },
        {
          name: 'Malware',
          value: 'Unknown',
          status: 'warning',
          icon: 'bug'
        },
        {
          name: 'Privacy',
          value: 'Unknown',
          status: 'warning',
          icon: 'user-secret'
        }
      ],
      securityFeatures: [
        {
          name: 'Could not connect to website',
          present: false
        }
      ],
      resourceAccess: [
        {
          name: 'Could not analyze resource access',
          status: 'not_requested',
          icon: 'times-circle'
        }
      ],
      vulnerabilities: [
        {
          name: 'Connection Issue',
          description: `Failed to connect to the website: ${error.message || 'Unknown error'}`,
          status: 'danger'
        }
      ],
      cookiesTrackers: {
        cookieCount: 0,
        trackerCount: 0,
        thirdPartyTracking: 'low',
        description: 'Could not analyze cookies and trackers due to connection error.'
      },
      recommendations: [
        {
          title: 'Check URL Correctness',
          description: 'Ensure the URL is correct and the website is accessible.'
        },
        {
          title: 'Verify Website Availability',
          description: 'Check if the website is currently online and accessible from your location.'
        }
      ]
    };
  }
}

export const securityScanner = new SecurityScanner();
