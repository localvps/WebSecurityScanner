#!/bin/bash

# Terminal colors for better display
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
NC='\033[0m' # No Color

# Display logo
echo -e "${PURPLE}"
echo " __        __   _    ____                      _ _           "
echo " \ \      / /__| |__/ ___|  ___  ___ _   _ _ __(_) |_ _   _  "
echo "  \ \ /\ / / _ \ '_ \___ \ / _ \/ __| | | | '__| | __| | | | "
echo "   \ V  V /  __/ |_) |__) |  __/ (__| |_| | |  | | |_| |_| | "
echo "    \_/\_/ \___|_.__/____/ \___|\___|\__,_|_|  |_|\__|\__, | "
echo "                                                       |___/  "
echo "  ____                                                        "
echo " / ___|  ___ __ _ _ __  _ __   ___ _ __                       "
echo " \___ \ / __/ _\` | '_ \| '_ \ / _ \ '__|                      "
echo "  ___) | (_| (_| | | | | | | |  __/ |                         "
echo " |____/ \___\__,_|_| |_|_| |_|\___|_|                         "
echo -e "${NC}"
echo -e "${BLUE}=== WebSecurity Scanner Automatic Installer ===${NC}"
echo ""

# Check prerequisites
echo -e "${YELLOW}[1/7] Checking prerequisites...${NC}"

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo -e "${RED}Node.js not found. Installing Node.js...${NC}"
    
    # Check OS type
    if command -v apt &> /dev/null; then
        # Debian-based OS like Ubuntu
        curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
        sudo apt install -y nodejs
    elif command -v yum &> /dev/null; then
        # Red Hat-based OS like CentOS
        curl -fsSL https://rpm.nodesource.com/setup_20.x | sudo bash -
        sudo yum install -y nodejs
    elif command -v brew &> /dev/null; then
        # macOS with Homebrew
        brew install node
    else
        echo -e "${RED}Your operating system is not supported. Please install Node.js manually:${NC}"
        echo "https://nodejs.org/en/download/"
        exit 1
    fi
else
    echo -e "${GREEN}Node.js is already installed.${NC}"
fi

# Check if npm is installed
if ! command -v npm &> /dev/null; then
    echo -e "${RED}npm not found. Installing npm...${NC}"
    sudo apt install -y npm
else
    echo -e "${GREEN}npm is already installed.${NC}"
fi

# Check if git is installed
if ! command -v git &> /dev/null; then
    echo -e "${RED}git not found. Installing git...${NC}"
    if command -v apt &> /dev/null; then
        sudo apt install -y git
    elif command -v yum &> /dev/null; then
        sudo yum install -y git
    elif command -v brew &> /dev/null; then
        brew install git
    else
        echo -e "${RED}Please install git manually.${NC}"
        exit 1
    fi
else
    echo -e "${GREEN}git is already installed.${NC}"
fi

echo -e "${GREEN}All prerequisites successfully checked.${NC}"
echo ""

# Ask for Git repository URL
echo -e "${YELLOW}[2/7] Preparing to download code...${NC}"
read -p "Enter the Git repository URL (leave empty to use code in current directory): " git_url
echo ""

if [ -z "$git_url" ]; then
    echo -e "${BLUE}Using code in the current directory.${NC}"
    PROJECT_DIR="$(pwd)"
else
    echo -e "${YELLOW}Downloading code from Git repository...${NC}"
    # Determine project folder name using Git repository name
    PROJECT_NAME=$(basename $git_url .git)
    
    # Clone Git repository
    git clone $git_url
    
    if [ $? -ne 0 ]; then
        echo -e "${RED}Error downloading code. Please check the Git repository URL.${NC}"
        exit 1
    fi
    
    PROJECT_DIR="$(pwd)/$PROJECT_NAME"
    cd $PROJECT_DIR
    echo -e "${GREEN}Code successfully downloaded.${NC}"
fi
echo ""

# Install npm dependencies
echo -e "${YELLOW}[3/7] Installing project dependencies...${NC}"
npm install

if [ $? -ne 0 ]; then
    echo -e "${RED}Error installing dependencies. Trying again with --legacy-peer-deps...${NC}"
    npm install --legacy-peer-deps
    
    if [ $? -ne 0 ]; then
        echo -e "${RED}Error installing dependencies. Please check the problem.${NC}"
        exit 1
    fi
fi

echo -e "${GREEN}Dependencies successfully installed.${NC}"
echo ""

# Build production version
echo -e "${YELLOW}[4/7] Building production version...${NC}"
npm run build

if [ $? -ne 0 ]; then
    echo -e "${RED}Error building production version. Please check the problem.${NC}"
    exit 1
fi

echo -e "${GREEN}Production version successfully built.${NC}"
echo ""

# Install PM2 for process management
echo -e "${YELLOW}[5/7] Installing and configuring PM2...${NC}"
if ! command -v pm2 &> /dev/null; then
    npm install -g pm2
    
    if [ $? -ne 0 ]; then
        echo -e "${RED}Error installing PM2. Trying with sudo...${NC}"
        sudo npm install -g pm2
        
        if [ $? -ne 0 ]; then
            echo -e "${RED}Error installing PM2. Please install manually:${NC}"
            echo "sudo npm install -g pm2"
            exit 1
        fi
    fi
else
    echo -e "${GREEN}PM2 is already installed.${NC}"
fi

# Launch application with PM2
echo -e "${YELLOW}[6/7] Starting application with PM2...${NC}"
pm2 start npm --name "websecurity-scanner" -- start

if [ $? -ne 0 ]; then
    echo -e "${RED}Error launching application with PM2. Please check the problem.${NC}"
    exit 1
fi

# Configure automatic startup with PM2 when system boots
echo -e "${YELLOW}[7/7] Setting up automatic startup on system boot...${NC}"
pm2 save

read -p "Do you want PM2 to automatically start when system boots? (y/n): " setup_startup

if [ "$setup_startup" = "y" ] || [ "$setup_startup" = "Y" ]; then
    pm2 startup
    
    if [ $? -ne 0 ]; then
        echo -e "${YELLOW}Please manually run the command that PM2 shows.${NC}"
    fi
    
    echo -e "${GREEN}Automatic startup configuration complete.${NC}"
else
    echo -e "${BLUE}Automatic startup not configured.${NC}"
fi

echo ""
echo -e "${GREEN}=== Installation and setup completed successfully! ===${NC}"
echo -e "${BLUE}The WebSecurity Scanner is now available at http://localhost:5000${NC}"
echo ""
echo -e "${YELLOW}Useful commands:${NC}"
echo -e "${PURPLE}pm2 status${NC} - View application status"
echo -e "${PURPLE}pm2 logs websecurity-scanner${NC} - View application logs"
echo -e "${PURPLE}pm2 restart websecurity-scanner${NC} - Restart application"
echo -e "${PURPLE}pm2 stop websecurity-scanner${NC} - Stop application"
echo ""
echo -e "${BLUE}To configure Nginx as a reverse proxy, please refer to README.md${NC}"
echo ""