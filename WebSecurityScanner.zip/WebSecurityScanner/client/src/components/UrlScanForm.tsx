import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Form, FormControl, FormField, FormItem, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { ScanResult } from "@/lib/types";
import { ArrowRight } from "lucide-react";

const urlSchema = z.object({
  url: z.string().url("Please enter a valid URL including http:// or https://")
});

type FormValues = z.infer<typeof urlSchema>;

interface UrlScanFormProps {
  onScanComplete: (result: ScanResult) => void;
  onScanStart: () => void;
}

export default function UrlScanForm({ onScanComplete, onScanStart }: UrlScanFormProps) {
  const { toast } = useToast();
  
  const form = useForm<FormValues>({
    resolver: zodResolver(urlSchema),
    defaultValues: {
      url: ""
    }
  });

  const scanMutation = useMutation({
    mutationFn: async (data: FormValues) => {
      const response = await apiRequest("POST", "/api/scan", data);
      return response.json();
    },
    onSuccess: (data: ScanResult) => {
      onScanComplete(data);
    },
    onError: (error) => {
      toast({
        title: "Scan Failed",
        description: error instanceof Error ? error.message : "Failed to scan URL. Please try again.",
        variant: "destructive"
      });
    }
  });

  const onSubmit = (data: FormValues) => {
    onScanStart();
    scanMutation.mutate(data);
  };

  // Ensure URL has a protocol
  const handleAutocomplete = (e: React.FocusEvent<HTMLInputElement>) => {
    const value = e.target.value.trim();
    if (value && !value.startsWith('http://') && !value.startsWith('https://')) {
      form.setValue('url', `https://${value}`, { shouldValidate: true });
    }
  };

  return (
    <div className="bg-secondary rounded-lg p-5 border border-border">
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="mb-0">
          <FormField
            control={form.control}
            name="url"
            render={({ field }) => (
              <FormItem>
                <FormControl>
                  <div className="flex">
                    <Input
                      {...field}
                      className="flex-grow rounded-r-none bg-background border-2 border-r-0 border-input focus:border-primary text-foreground placeholder-muted-foreground"
                      placeholder="https://example.com"
                      onBlur={handleAutocomplete}
                      disabled={scanMutation.isPending}
                    />
                    <Button 
                      type="submit" 
                      className="rounded-l-none"
                      disabled={scanMutation.isPending}
                    >
                      <span>Scan</span>
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                  </div>
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
        </form>
      </Form>
    </div>
  );
}
