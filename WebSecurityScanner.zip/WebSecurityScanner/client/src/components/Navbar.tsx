import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Shield } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function Navbar() {
  const [location] = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  return (
    <header className="bg-secondary shadow-md fixed w-full z-10 border-b border-border">
      <div className="container mx-auto px-4 py-3 flex justify-between items-center">
        <div className="flex items-center">
          <Shield className="text-primary h-6 w-6 mr-2" />
          <h1 className="text-xl font-bold text-foreground">WebSecurityScan</h1>
        </div>
        <div className="hidden md:flex items-center space-x-4">
          <Link href="/">
            <a className={`text-sm font-medium transition-colors ${location === "/" ? "text-primary" : "text-muted-foreground hover:text-primary"}`}>
              Dashboard
            </a>
          </Link>
          <Link href="/history">
            <a className={`text-sm font-medium transition-colors ${location === "/history" ? "text-primary" : "text-muted-foreground hover:text-primary"}`}>
              History
            </a>
          </Link>
          <Link href="/about">
            <a className={`text-sm font-medium transition-colors ${location === "/about" ? "text-primary" : "text-muted-foreground hover:text-primary"}`}>
              About
            </a>
          </Link>
        </div>
        <div className="md:hidden">
          <Button 
            variant="ghost" 
            size="sm"
            onClick={toggleMobileMenu}
            aria-label="Toggle mobile menu"
          >
            <svg 
              xmlns="http://www.w3.org/2000/svg" 
              className="h-6 w-6" 
              fill="none" 
              viewBox="0 0 24 24" 
              stroke="currentColor"
            >
              <path 
                strokeLinecap="round" 
                strokeLinejoin="round" 
                strokeWidth={2} 
                d="M4 6h16M4 12h16M4 18h16" 
              />
            </svg>
          </Button>
        </div>
      </div>
      
      {/* Mobile menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden bg-secondary border-t border-border">
          <div className="container mx-auto px-4 py-2 flex flex-col space-y-2">
            <Link href="/">
              <a 
                className={`py-2 px-3 rounded-md transition-colors ${location === "/" ? "text-primary bg-primary/10" : "text-foreground hover:bg-muted"}`}
                onClick={() => setIsMobileMenuOpen(false)}
              >
                Dashboard
              </a>
            </Link>
            <Link href="/history">
              <a 
                className={`py-2 px-3 rounded-md transition-colors ${location === "/history" ? "text-primary bg-primary/10" : "text-foreground hover:bg-muted"}`}
                onClick={() => setIsMobileMenuOpen(false)}
              >
                History
              </a>
            </Link>
            <Link href="/about">
              <a 
                className={`py-2 px-3 rounded-md transition-colors ${location === "/about" ? "text-primary bg-primary/10" : "text-foreground hover:bg-muted"}`}
                onClick={() => setIsMobileMenuOpen(false)}
              >
                About
              </a>
            </Link>
          </div>
        </div>
      )}
    </header>
  );
}
