import { Card, CardContent } from "@/components/ui/card";
import { AspectRatio } from "@/components/ui/aspect-ratio";

export default function FeatureCards() {
  const features = [
    {
      title: "Comprehensive Analysis",
      description: "Our scanner checks for over 100 different security vulnerabilities and privacy issues.",
      image: "https://images.unsplash.com/photo-1558050032-160f36233a07?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=500",
      alt: "Cybersecurity analysis"
    },
    {
      title: "Real-time Scanning",
      description: "Get instant results about the security status of any website before you share sensitive information.",
      image: "https://images.unsplash.com/photo-1614064641938-3bbee52942c7?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=500",
      alt: "Website security protection"
    },
    {
      title: "Actionable Recommendations",
      description: "We don't just identify problems - we provide clear solutions to improve website security.",
      image: "https://images.unsplash.com/photo-1544890225-2f3faec4cd60?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=500",
      alt: "Protection against security threats"
    }
  ];

  return (
    <section className="my-10">
      <h2 className="text-2xl font-bold mb-6">Why Use Our Scanner?</h2>
      <div className="grid md:grid-cols-3 gap-6">
        {features.map((feature, index) => (
          <Card key={index} className="bg-secondary border-border overflow-hidden">
            <AspectRatio ratio={16/9}>
              <img 
                src={feature.image} 
                alt={feature.alt} 
                className="w-full h-full object-cover"
              />
            </AspectRatio>
            <CardContent className="p-5">
              <h3 className="text-lg font-semibold mb-2">{feature.title}</h3>
              <p className="text-muted-foreground">{feature.description}</p>
            </CardContent>
          </Card>
        ))}
      </div>
    </section>
  );
}
