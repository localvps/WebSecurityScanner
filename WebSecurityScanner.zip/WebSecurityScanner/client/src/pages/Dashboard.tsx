import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { ScanResult } from "@/lib/types";
import UrlScanForm from "@/components/UrlScanForm";
import LoadingState from "@/components/LoadingState";
import ScanResults from "@/components/ScanResults";
import HistoryTable from "@/components/HistoryTable";
import FeatureCards from "@/components/FeatureCards";
import { Shield } from "lucide-react";
import { useLocation, useSearch } from "wouter";

export default function Dashboard() {
  const [location, setLocation] = useLocation();
  const search = useSearch();
  const queryParams = new URLSearchParams(search);
  const scanIdFromUrl = queryParams.get('scanId');
  
  const [isScanning, setIsScanning] = useState(false);
  const [scanUrl, setScanUrl] = useState<string>("");
  const [scanResult, setScanResult] = useState<ScanResult | null>(null);
  
  // Fetch recent scans for history section
  const { 
    data: recentScans, 
    isLoading: isLoadingHistory 
  } = useQuery({
    queryKey: ['/api/scans/recent'], 
    queryOptions: {
      refetchOnWindowFocus: false
    }
  });
  
  // If scanId is present in URL, fetch that specific scan
  const { 
    data: specificScanResult,
    isLoading: isLoadingSpecificScan
  } = useQuery({
    queryKey: [`/api/scans/${scanIdFromUrl}`],
    enabled: !!scanIdFromUrl,
    queryOptions: {
      refetchOnWindowFocus: false
    }
  });
  
  // When a specific scan is loaded from URL
  useEffect(() => {
    if (specificScanResult && !isLoadingSpecificScan) {
      setScanResult(specificScanResult);
      setScanUrl(specificScanResult.url);
    }
  }, [specificScanResult, isLoadingSpecificScan]);
  
  // Handle scan start
  const handleScanStart = () => {
    setIsScanning(true);
    setScanResult(null);
    
    // Remove any scanId from URL when starting a new scan
    if (scanIdFromUrl) {
      setLocation('/', { replace: true });
    }
  };
  
  // Handle scan completion
  const handleScanComplete = (result: ScanResult) => {
    setIsScanning(false);
    setScanResult(result);
    setScanUrl(result.url);
  };

  return (
    <>
      <section className="mb-10">
        <div className="grid md:grid-cols-2 gap-8">
          <div className="flex flex-col justify-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-foreground">Website Security Scanner</h2>
            <p className="text-muted-foreground mb-6">
              Analyze any website for security vulnerabilities, malware, and privacy issues.
              Get a complete security report with a 0-100 score and detailed recommendations.
            </p>
            
            <UrlScanForm 
              onScanStart={handleScanStart} 
              onScanComplete={handleScanComplete}
            />
          </div>
          
          <div className="flex items-center justify-center">
            <img 
              src="https://images.unsplash.com/photo-1563986768609-322da13575f3?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600" 
              alt="Cybersecurity protection illustration" 
              className="rounded-xl shadow-lg max-h-80"
            />
          </div>
        </div>
      </section>
      
      {isScanning && <LoadingState url={scanUrl} />}
      
      {scanResult && <ScanResults result={scanResult} />}
      
      {!isScanning && !scanResult && (
        <section className="my-10 py-10 text-center border border-border rounded-lg bg-secondary/50">
          <Shield className="h-16 w-16 text-primary mx-auto mb-4" />
          <h3 className="text-xl font-semibold mb-2">Ready to Scan</h3>
          <p className="text-muted-foreground max-w-md mx-auto">
            Enter a website URL above to analyze its security and privacy features.
          </p>
        </section>
      )}
      
      {/* Recent Scans Section */}
      <section className="my-10">
        <h2 className="text-2xl font-bold mb-5 flex items-center">
          <svg className="w-5 h-5 text-primary mr-2" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
            <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-12a1 1 0 10-2 0v4a1 1 0 00.293.707l2.828 2.829a1 1 0 101.415-1.415L11 9.586V6z" clipRule="evenodd"></path>
          </svg>
          Recent Scans
        </h2>
        <HistoryTable 
          scans={recentScans || []} 
          isLoading={isLoadingHistory} 
        />
      </section>
      
      <FeatureCards />
    </>
  );
}
