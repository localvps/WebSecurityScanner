import { useState, useEffect } from "react";
import { Progress } from "@/components/ui/progress";

interface LoadingStateProps {
  url: string;
}

export default function LoadingState({ url }: LoadingStateProps) {
  const [progress, setProgress] = useState(0);
  const [statusText, setStatusText] = useState('Initializing scan...');

  useEffect(() => {
    const statuses = [
      'Checking SSL certificate...',
      'Analyzing security headers...',
      'Scanning for vulnerabilities...',
      'Checking resource permissions...',
      'Inspecting cookies and trackers...',
      'Finalizing security report...'
    ];
    
    let currentStatus = 0;
    // Reset progress when URL changes
    setProgress(0);
    
    // Simulate progress updates
    const interval = setInterval(() => {
      setProgress(prev => {
        const newProgress = prev + Math.random() * 5 + 2;
        
        // Update status text at certain progress points
        if (newProgress > 15 && currentStatus === 0) {
          setStatusText(statuses[1]);
          currentStatus = 1;
        } else if (newProgress > 35 && currentStatus === 1) {
          setStatusText(statuses[2]);
          currentStatus = 2;
        } else if (newProgress > 55 && currentStatus === 2) {
          setStatusText(statuses[3]);
          currentStatus = 3;
        } else if (newProgress > 70 && currentStatus === 3) {
          setStatusText(statuses[4]);
          currentStatus = 4;
        } else if (newProgress > 85 && currentStatus === 4) {
          setStatusText(statuses[5]);
          currentStatus = 5;
        }
        
        return newProgress > 95 ? 95 : newProgress;
      });
    }, 200);
    
    return () => clearInterval(interval);
  }, [url]);

  return (
    <section className="my-10 text-center py-16">
      <div className="flex flex-col items-center">
        <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin mb-4"></div>
        <h3 className="text-xl font-semibold mb-2">Scanning Website Security</h3>
        <p className="text-muted-foreground">{url}</p>
        <div className="mt-6 max-w-md mx-auto w-full">
          <Progress value={progress} className="h-2" />
          
          <div className="flex justify-between mt-2 text-sm text-muted-foreground">
            <span>{statusText}</span>
            <span>{Math.round(progress)}%</span>
          </div>
        </div>
      </div>
    </section>
  );
}
