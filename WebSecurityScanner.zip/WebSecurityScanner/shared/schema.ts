import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Website scan result schema
export const scans = pgTable("scans", {
  id: serial("id").primaryKey(),
  url: text("url").notNull(),
  score: integer("score").notNull(),
  status: text("status").notNull(),
  scanDate: timestamp("scan_date").defaultNow().notNull(),
  securityDetails: text("security_details").notNull(), // JSON stringified
  vulnerabilities: text("vulnerabilities").notNull(), // JSON stringified
  resourceAccess: text("resource_access").notNull(), // JSON stringified
  cookiesTrackers: text("cookies_trackers").notNull(), // JSON stringified
  recommendations: text("recommendations").notNull(), // JSON stringified
});

export const insertScanSchema = createInsertSchema(scans).omit({
  id: true,
  scanDate: true,
});

export type InsertScan = z.infer<typeof insertScanSchema>;
export type Scan = typeof scans.$inferSelect;

// Define a zod schema for URL validation
export const urlSchema = z.object({
  url: z.string().url("Please enter a valid URL including http:// or https://"),
});

// Define types for different security components
export type SecurityDetail = {
  name: string;
  status: 'success' | 'warning' | 'danger';
  icon: string;
};

export type SecurityMetric = {
  name: string;
  value: string;
  status: 'success' | 'warning' | 'danger';
  icon: string;
};

export type Vulnerability = {
  name: string;
  description: string;
  status: 'success' | 'warning' | 'danger';
};

export type ResourceAccessItem = {
  name: string;
  status: 'requested' | 'not_requested';
  icon: string;
};

export type CookiesTrackersDetail = {
  cookieCount: number;
  trackerCount: number;
  thirdPartyTracking: 'low' | 'moderate' | 'high';
  description: string;
};

export type Recommendation = {
  title: string;
  description: string;
};

export type SecurityFeature = {
  name: string;
  present: boolean;
};

// Define a full scan result type that combines all security details
export type ScanResult = {
  url: string;
  score: number;
  status: 'secure' | 'warning' | 'vulnerable';
  scanDate: string;
  securityMetrics: SecurityMetric[];
  securityFeatures: SecurityFeature[];
  resourceAccess: ResourceAccessItem[];
  vulnerabilities: Vulnerability[];
  cookiesTrackers: CookiesTrackersDetail;
  recommendations: Recommendation[];
};
