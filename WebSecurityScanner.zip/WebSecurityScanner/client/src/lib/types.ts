// Common types used throughout the frontend application

export type ScanHistoryItem = {
  id: number;
  url: string;
  score: number;
  status: 'secure' | 'warning' | 'vulnerable';
  scanDate: string;
};

export type SecurityMetric = {
  name: string;
  value: string;
  status: 'success' | 'warning' | 'danger';
  icon: string;
};

export type SecurityFeature = {
  name: string;
  present: boolean;
};

export type ResourceAccessItem = {
  name: string;
  status: 'requested' | 'not_requested';
  icon: string;
};

export type Vulnerability = {
  name: string;
  description: string;
  status: 'success' | 'warning' | 'danger';
};

export type CookiesTrackersDetail = {
  cookieCount: number;
  trackerCount: number;
  thirdPartyTracking: 'low' | 'moderate' | 'high';
  description: string;
};

export type Recommendation = {
  title: string;
  description: string;
};

export type ScanResult = {
  url: string;
  score: number;
  status: 'secure' | 'warning' | 'vulnerable';
  scanDate: string;
  securityMetrics: SecurityMetric[];
  securityFeatures: SecurityFeature[];
  resourceAccess: ResourceAccessItem[];
  vulnerabilities: Vulnerability[];
  cookiesTrackers: CookiesTrackersDetail;
  recommendations: Recommendation[];
};
