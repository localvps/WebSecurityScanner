import { Shield } from "lucide-react";
import { Link } from "wouter";

export default function Footer() {
  return (
    <footer className="bg-secondary py-8 border-t border-border">
      <div className="container mx-auto px-4">
        <div className="flex flex-col md:flex-row justify-between">
          <div className="mb-6 md:mb-0">
            <div className="flex items-center mb-4">
              <Shield className="text-primary h-6 w-6 mr-2" />
              <span className="text-xl font-bold text-foreground">WebSecurityScan</span>
            </div>
            <p className="text-muted-foreground max-w-md">
              Protect yourself online by checking website security before sharing sensitive information.
            </p>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-3 gap-8">
            <div>
              <h3 className="text-lg font-semibold mb-4 text-foreground">Product</h3>
              <ul className="space-y-2">
                <li><a href="#" className="text-muted-foreground hover:text-primary transition">Features</a></li>
                <li><a href="#" className="text-muted-foreground hover:text-primary transition">API</a></li>
                <li><a href="#" className="text-muted-foreground hover:text-primary transition">Pricing</a></li>
              </ul>
            </div>
            
            <div>
              <h3 className="text-lg font-semibold mb-4 text-foreground">Resources</h3>
              <ul className="space-y-2">
                <li><a href="#" className="text-muted-foreground hover:text-primary transition">Documentation</a></li>
                <li><a href="#" className="text-muted-foreground hover:text-primary transition">Blog</a></li>
                <li><a href="#" className="text-muted-foreground hover:text-primary transition">Security Tips</a></li>
              </ul>
            </div>
            
            <div>
              <h3 className="text-lg font-semibold mb-4 text-foreground">Company</h3>
              <ul className="space-y-2">
                <li>
                  <Link href="/about">
                    <a className="text-muted-foreground hover:text-primary transition">About</a>
                  </Link>
                </li>
                <li><a href="#" className="text-muted-foreground hover:text-primary transition">Contact</a></li>
                <li><a href="#" className="text-muted-foreground hover:text-primary transition">Privacy Policy</a></li>
              </ul>
            </div>
          </div>
        </div>
        
        <div className="mt-8 pt-6 border-t border-border text-center text-muted-foreground text-sm">
          <p>&copy; {new Date().getFullYear()} WebSecurityScan. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
