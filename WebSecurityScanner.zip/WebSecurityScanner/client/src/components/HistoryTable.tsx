import { ScanHistoryItem } from "@/lib/types";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { Eye } from "lucide-react";

interface HistoryTableProps {
  scans: ScanHistoryItem[];
  isLoading: boolean;
}

export default function HistoryTable({ scans, isLoading }: HistoryTableProps) {
  // Function to render status badge
  const renderStatusBadge = (status: string) => {
    switch (status) {
      case 'secure':
        return <Badge className="bg-green-600">Secure</Badge>;
      case 'warning':
        return <Badge className="bg-amber-500">Warning</Badge>;
      case 'vulnerable':
        return <Badge className="bg-red-600">Vulnerable</Badge>;
      default:
        return <Badge>Unknown</Badge>;
    }
  };
  
  if (isLoading) {
    return (
      <Card className="w-full overflow-hidden animate-pulse">
        <div className="p-4 space-y-4">
          <div className="h-6 bg-secondary rounded"></div>
          <div className="space-y-2">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="h-12 bg-secondary rounded"></div>
            ))}
          </div>
        </div>
      </Card>
    );
  }
  
  if (scans.length === 0) {
    return (
      <Card className="bg-secondary border-border">
        <div className="p-6 text-center">
          <p className="mb-4 text-muted-foreground">No scan history available yet.</p>
          <Link href="/">
            <Button>Scan a Website</Button>
          </Link>
        </div>
      </Card>
    );
  }

  return (
    <div className="overflow-x-auto bg-secondary rounded-xl shadow-lg border border-border">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Website</TableHead>
            <TableHead>Score</TableHead>
            <TableHead>Status</TableHead>
            <TableHead>Date</TableHead>
            <TableHead className="text-right">Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {scans.map((scan) => (
            <TableRow key={scan.id}>
              <TableCell className="font-medium">{new URL(scan.url).hostname}</TableCell>
              <TableCell>{scan.score}/100</TableCell>
              <TableCell>{renderStatusBadge(scan.status)}</TableCell>
              <TableCell>{scan.scanDate}</TableCell>
              <TableCell className="text-right">
                <Link href={`/?scanId=${scan.id}`}>
                  <Button variant="ghost" size="sm" className="text-primary hover:text-red-400">
                    <Eye className="h-4 w-4 mr-1" />
                    View Report
                  </Button>
                </Link>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}
