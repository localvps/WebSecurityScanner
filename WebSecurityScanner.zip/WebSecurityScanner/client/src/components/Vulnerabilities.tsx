import { Card, CardContent } from "@/components/ui/card";
import { Vulnerability } from "@/lib/types";
import { Bug, AlertTriangle } from "lucide-react";

interface VulnerabilitiesProps {
  vulnerabilities: Vulnerability[];
}

export default function Vulnerabilities({ vulnerabilities }: VulnerabilitiesProps) {
  if (vulnerabilities.length === 0) {
    return (
      <Card className="bg-secondary border-border h-full">
        <CardContent className="pt-5">
          <div className="flex items-center mb-4">
            <div className="w-10 h-10 rounded-full bg-green-900/30 flex items-center justify-center mr-3">
              <Bug className="text-status-success" />
            </div>
            <h3 className="text-lg font-semibold">Vulnerabilities</h3>
          </div>
          <div className="p-4 bg-background rounded-lg text-center">
            <p className="text-muted-foreground">No vulnerabilities detected</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-secondary border-border h-full">
      <CardContent className="pt-5">
        <div className="flex items-center mb-4">
          <div className="w-10 h-10 rounded-full bg-red-900/30 flex items-center justify-center mr-3">
            <Bug className="text-status-danger" />
          </div>
          <h3 className="text-lg font-semibold">Vulnerabilities</h3>
        </div>
        
        <ul className="space-y-3">
          {vulnerabilities.map((vulnerability, index) => (
            <li key={index} className="bg-background rounded-lg p-3">
              <div className="flex items-center mb-2">
                <AlertTriangle className={`${vulnerability.status === 'danger' ? 'text-status-danger' : 'text-status-warning'} mr-2 h-5 w-5`} />
                <span className="font-medium">{vulnerability.name}</span>
              </div>
              <p className="text-muted-foreground text-sm">{vulnerability.description}</p>
            </li>
          ))}
        </ul>
      </CardContent>
    </Card>
  );
}
