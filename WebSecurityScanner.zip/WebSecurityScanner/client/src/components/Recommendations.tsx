import { Card, CardContent } from "@/components/ui/card";
import { Recommendation } from "@/lib/types";
import { Lightbulb } from "lucide-react";

interface RecommendationsProps {
  recommendations: Recommendation[];
}

export default function Recommendations({ recommendations }: RecommendationsProps) {
  if (recommendations.length === 0) {
    return (
      <Card className="bg-secondary border-border">
        <CardContent className="pt-6">
          <h3 className="text-xl font-semibold mb-4 flex items-center">
            <Lightbulb className="text-yellow-400 mr-2 h-5 w-5" />
            Security Recommendations
          </h3>
          <div className="p-4 bg-background rounded-lg text-center">
            <p className="text-muted-foreground">No recommendations needed - your site security looks good!</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-secondary border-border">
      <CardContent className="pt-6">
        <h3 className="text-xl font-semibold mb-4 flex items-center">
          <Lightbulb className="text-yellow-400 mr-2 h-5 w-5" />
          Security Recommendations
        </h3>
        
        <div className="grid md:grid-cols-2 gap-4">
          {recommendations.map((recommendation, index) => (
            <div key={index} className="bg-background rounded-lg p-4">
              <h4 className="font-medium mb-2">{recommendation.title}</h4>
              <p className="text-muted-foreground text-sm">{recommendation.description}</p>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
